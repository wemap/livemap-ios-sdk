//
//  livemap_ios_sdk.h
//  livemap-ios-sdk
//
//  Created by Bertrand Mathieu-Daudé on 21/02/2020.
//  Copyright © 2020 Bertrand Mathieu-Daudé. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for livemap_ios_sdk.
FOUNDATION_EXPORT double livemap_ios_sdkVersionNumber;

//! Project version string for livemap_ios_sdk.
FOUNDATION_EXPORT const unsigned char livemap_ios_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <livemap_ios_sdk/PublicHeader.h>


